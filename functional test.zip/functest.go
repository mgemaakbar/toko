package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
	"sync"
)

func f() {
	req, err := http.NewRequest("POST", "http://localhost:10000/buy", strings.NewReader(`{"sku": "x", "quantity": 1 }`))
	if err != nil {
		log.Fatalln(err)
		return
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		panic(err)
	}

	defer resp.Body.Close()
	//We Read the response body on the line below.
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalln(err)
	}
	//Convert the body to type string
	sb := string(body)
	log.Printf(sb)

}

func main() {
	wg := sync.WaitGroup{}
	n := 100

	wg.Add(n)
	for i := 0; i < n; i++ {
		go func() {
			defer wg.Done()
			f()
		}()
	}
	wg.Wait()
	fmt.Println("Done")
}
